package com.cg.pp.dao;

import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import com.cg.pp.bean.AccountHolder;
import com.cg.pp.bean.Transactions;
import com.cg.pp.bean.Wallet;
import com.cg.pp.exception.AccountNotExistException;
import com.cg.pp.exception.NotEnoughBalanceException;
import com.cg.pp.util.CollectionUtil;

public class AccountDao implements IAccountDao{

	EntityManager em=null;
	EntityTransaction entitytran=null;
	AccountHolder account=null;
	static int transactionID=1;
	public AccountDao() 
	{
		em=CollectionUtil.getEntityManager();
		entitytran=em.getTransaction();
	}

	@Override
	public void createAccount(String firstName, String lastName, String mobileNo, String gender, int age,
			double amount) {
		// TODO Auto-generated method stub 
		 account=new AccountHolder(mobileNo,firstName,lastName,gender,age,amount);
		 entitytran.begin();
		 em.persist(account);
		 entitytran.commit();
		 System.out.println("Account created successfully");
	}

	@Override
	public AccountHolder withdrawAmount(String mobileNo, double amount) throws NotEnoughBalanceException, AccountNotExistException 
	{
		entitytran.begin();
		AccountHolder account=em.find(AccountHolder.class, mobileNo);
		if(account==null)
		{
			throw new AccountNotExistException("Account does not exist");
		}
		else
		{
			account.getWallet().setBalance(account.getWallet().getBalance()-amount);
			em.merge(account);
			entitytran.commit();
			return account;
		}
	}	
		

	@Override
	public AccountHolder depositAmount(String mobileNo, double amount) throws AccountNotExistException {
		
		entitytran.begin();
		AccountHolder account=em.find(AccountHolder.class, mobileNo);
		if(account==null)
		{
			throw new AccountNotExistException("Account does not exist");
		}
		else
		{
			account.getWallet().setBalance(account.getWallet().getBalance()+amount);
			em.merge(account);
			entitytran.commit();
			return account;
		}
		
	}

	@Override
	public double showBalance(String mobileNo) throws AccountNotExistException {
		AccountHolder account=em.find(AccountHolder.class, mobileNo);
		if(account==null)
		{
			throw new AccountNotExistException("Account does not exist");
		}
		else
		{
			return account.getWallet().getBalance();
			
		}
	}

	@Override
	public String fundTransfer(String senderMobileNo,String receiverMobileNo, double amount) throws AccountNotExistException, NotEnoughBalanceException {
		AccountHolder senderAccount=null;
		AccountHolder receiverAccount=null;
		 senderAccount=em.find(AccountHolder.class, senderMobileNo);
		 receiverAccount=em.find(AccountHolder.class, receiverMobileNo);
		 senderAccount.getWallet().setBalance(senderAccount.getWallet().getBalance()-amount);
		 receiverAccount.getWallet().setBalance(receiverAccount.getWallet().getBalance()+amount);
		 entitytran.begin();
		 em.merge(senderAccount);
		 em.merge(receiverAccount);
		 entitytran.commit();
		 return "Fund successfully transferred";
	}

	@Override
	public void printTtansaction(String mobileNo) 
	{
		account=em.find(AccountHolder.class, mobileNo);
		System.out.println(account.getWallet().getTransaction().getListTransaction());
	}
}


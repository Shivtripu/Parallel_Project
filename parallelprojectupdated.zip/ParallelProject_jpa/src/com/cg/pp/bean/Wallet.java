package com.cg.pp.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Wallet 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int walletNo;
	@Column(name="balance",length=10)
	private double balance;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="transaction")
	Transactions transaction;
	
	public Wallet() {
		super();
		transaction=new Transactions();
	}
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	

	public Transactions getTransaction() {
		return transaction;
	}
	public void setTransaction(Transactions transaction) {
		this.transaction = transaction;
	}
	@Override
	public String toString() 
	{
		System.out.println("-----------------------------------------------------------------------");
		return "balance=" + balance;
	}
	
}

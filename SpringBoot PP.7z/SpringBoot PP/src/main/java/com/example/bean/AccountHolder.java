package com.example.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Account")
public class AccountHolder 
{
	@Id
	@Column(name="mobileno",length=30)
	private String MobileNo;
	
	@Column(name="firstname",length=30)
	private String firstName;
	
	@Column(name="lastname",length=30)
	private String lastName;
	
	@Column(name="gender",length=30)
	private String gender;
	
	@Column(name="age",length=30)
	private int age;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Wallet wallet;
	
	public AccountHolder() {
		super();
	}

	public AccountHolder( String mobileNo,String firstName, String lastName, String gender, int age,double amount) {
		this.MobileNo=mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.wallet = new Wallet();
		wallet.setBalance(amount);
		wallet.getListTransaction().add(new Transactions("Credit",amount));
	}
	
	public String getMobileNo() {
		return MobileNo;
	}

	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}

	public Wallet getWallet() {
		return wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() 
	{
		System.out.println("-----------------------------------------------------------------------");
		return "firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender +
				", age=" + age + ", wallet=" + wallet;
	}
	
}
